extern void prename_setproctitle_init(int argc, char **argv, char **envp);
extern void prename_setproctitle(const char *fmt, ...);
